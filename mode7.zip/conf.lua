function love.conf(v)
 --configure game
 v.title = "Mode7"
 v.author = "A. Kidd"
 v.window.width = 1440
 v.window.height = 900
 v.window.fullscreen = false
end